const express=require("express");
const https=require("https");//native
const bodyParser=require("body-parser");
const app=express();
app.use(bodyParser.urlencoded({extended:true}));
app.get("/",function(req,res){  //broweser ne request kiya server se and server ne respond kiya browser ko
  //requesting another server
 res.sendFile(__dirname+"/index.html"); //as sendFile as index.html is file we get it on broweser
    
})
app.post("/",function(req,res){      


  const query=req.body.cityName;//dynamic data
  const apiKey="99e451a11318e3f30c00e80d462bb18e";
  const unit="metric";
    https.get("https://api.openweathermap.org/data/2.5/weather?q="+query+"&apikey="+apiKey+"&units="+unit,function(response){//my  server asking request from other server
       console.log (response.statusCode); //getting response on our server
       response.on("data",function(data){
        const weatherData=JSON.parse(data);//to convert data into json string

        console.log(weatherData);
        const temp=weatherData.main.temp;
        const feelLike=weatherData.main.feels_like;
       const description= weatherData.weather[0].description;
       const icon=weatherData.weather[0].icon;
       const url="https://openweathermap.org/img/wn/"+icon+"@2x.png";
        console.log(temp);
        console.log(feelLike);
        console.log(description);
        res.write("<h1>the temp in "+query+" is:"+temp+"degrees celsius</h1>");// shows on browser(many write but one send only)
        res.write("<p>the weather is currently"+description+"</p>");
        res.write("<img src="+url+">");
        res.send();
       })
    })









})
/*const query="india";
  const apiKey="99e451a11318e3f30c00e80d462bb18e";
  const units="metric";
    https.get("https://api.openweathermap.org/data/2.5/weather?"+query+"&apikey="+apiKey+"&units="+units,function(response){
       console.log (response.statusCode); //getting response on our server
       response.on("data",function(data){
        const weatherData=JSON.parse(data);//to convert data into json string

        console.log(weatherData);
        const temp=weatherData.main.temp;
        const feelLike=weatherData.main.feels_like;
       const description= weatherData.weather[0].description;
       const icon=weatherData.weather[0].icon;
       const url="https://openweathermap.org/img/wn/"+icon+"@2x.png";
        console.log(temp);
        console.log(feelLike);
        console.log(description);
        res.write("<h1>the temp in gorakhpur is:"+temp+"degrees celsius</h1>");// shows on browser(many write but one send only)
        res.write("<p>the weather is currently"+description+"</p>");
        res.write("<img src="+url+">");
        res.send();
       })
    })*/









app.listen(3000,function(){
  console.log("port is running on server 3000");
})